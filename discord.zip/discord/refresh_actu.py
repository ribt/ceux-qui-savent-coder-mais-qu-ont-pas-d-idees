import discord
import asyncio
import time
import feedparser
import codecs

feeds = ["https://news.google.com/news/rss/headlines/section/topic/SCITECH.fr_fr/Science%2FHigh-Tech?ned=fr&hl=fr",
         "http://www.commitstrip.com/fr/feed/",
         "https://korben.info/feed",
         "https://www.begeek.fr/feed",
         "http://blogmotion.fr/feed",
         "http://www.framboise314.fr/feed/", "http://www.journaldugeek.com/feed/",
         "https://thehackernews.com/feeds/posts/default",
         "https://usbeketrica.com/rss",
         "https://www.lemondeinformatique.fr/flux-rss/"]

dernier = time.gmtime(1514817667)

client = discord.Client()

@client.event
async def on_ready():
    actu = client.get_channel("397020219740127233")
    for feed in feeds :
        print (feed)
        rss = feedparser.parse(feed)['entries']
        i = 0
        while i < len(rss) :
            if rss[i]['published_parsed'] > dernier :
                print (rss[i]['link'])
                await client.send_message(actu, rss[i]['link'])
            i += 1
                
client.run('MzgwNzc1Njk0NDExNDk3NDkz.DO9g2w.aviWFaQVtp8E2L127s0T3lhxH2w')
