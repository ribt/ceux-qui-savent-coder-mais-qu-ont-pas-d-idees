import feedparser
feeds = ["http://www.commitstrip.com/fr/feed/", "https://korben.info/feed"]
rss = feedparser.parse("http://www.commitstrip.com/fr/feed/")
dernier = "http://www.commitstrip.com/fr/2017/12/12/the-code-is-always-better-on-the-other-side/"
links = []
i = 0
while i < len(rss['entries']):
    if rss['entries'][i]['link'] == dernier : break
    else : links.append(rss['entries'][i]['link'])
    i += 1
for i in reversed(links) : print (i)

