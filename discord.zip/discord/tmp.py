import discord
import asyncio

client = discord.Client()


@client.event
async def on_ready():
    print('OK')
    serv1 = client.get_server("368691752946892801")
    serv2 = client.get_server("401667451189985280")
    #secret = client.get_channel("404375736254988288")
    ribt1 = serv1.get_member("321675705010225162")
    ribt2 = serv2.get_member("321675705010225162")
    await client.send_message(ribt2, "cc")

client.run('MzgwNzc1Njk0NDExNDk3NDkz.DO9g2w.aviWFaQVtp8E2L127s0T3lhxH2w')
