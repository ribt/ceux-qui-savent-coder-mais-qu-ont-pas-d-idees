from urllib.request import urlopen
import json
from html import unescape

dn = "google.com"

data = urlopen("https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=at_WQ1sJpiEOETxoExX9rWFB4X1gx0kq&outputFormat=JSON&domainName=" + dn)
data = unescape(data.read().decode("utf-8"))
data = json.loads(data)['WhoisRecord']['registryData']['administrativeContact']['rawText'].split("\n")
txt = tmp = ""
i = 0
while len(tmp) <= 400 and i < len(data):
    txt = tmp
    tmp += data[i] + "\n"
    i += 1
print (txt)
