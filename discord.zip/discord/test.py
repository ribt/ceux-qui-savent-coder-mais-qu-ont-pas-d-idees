import asyncio
import discord
import json

dico = {}
dico['401667451189985280'] = {}
dico['401667451189985280']['mp_accueil'] = """Bonjour et bienvenue sur ce superbe serveur \N{GRINNING FACE WITH SMILING EYES}
Le but de ce serveur est de propser aux devs qui n'ont pas trop d'insipiration des idées et des défis. N'hésite pas à aller jeter un coup d'oeil dans #regles (c'est pas hyper intéressant mais pas le choix) et dans #annonces (là c'est plus intéressant tu vas avoir quelques infos sympas).
Profite bien !"""

with open("config.json", "w") as f : json.dump(dico, f, indent=4)

"""
client = discord.Client()
@client.event
async def on_ready():
    await client.send_message(client.get_channel("404375736254988288"), dico['401667451189985280']['mp_accueil'])
client.run('MzgwNzc1Njk0NDExNDk3NDkz.DO9g2w.aviWFaQVtp8E2L127s0T3lhxH2w')
"""
