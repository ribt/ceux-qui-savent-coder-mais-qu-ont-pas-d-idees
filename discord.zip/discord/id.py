import discord
import asyncio

client = discord.Client()

@client.event
async def on_ready():
    for server in client.servers:
        print ("\n" + str(server) + " : " + server.id + "\n")
        for channel in server.channels:
            print ("- " + str(channel) + " : " + channel.id)
    client.close()

client.run('MzgwNzc1Njk0NDExNDk3NDkz.DO9g2w.aviWFaQVtp8E2L127s0T3lhxH2w')

