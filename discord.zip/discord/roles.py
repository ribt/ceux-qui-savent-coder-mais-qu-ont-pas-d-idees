import discord
import asyncio

client = discord.Client()


@client.event
async def on_ready():
    print('OK')
    serv = client.get_server("401667451189985280")
    for i in serv.roles :
        print (i.name, i.id, str(i.colour), type(str(i.colour)))

client.run('MzgwNzc1Njk0NDExNDk3NDkz.DO9g2w.aviWFaQVtp8E2L127s0T3lhxH2w')
