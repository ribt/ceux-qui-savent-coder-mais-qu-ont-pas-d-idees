import random
with open("wordlist/courants.txt", "r") as f : mots = f.read().split("\n")
mot = random.choice(mots)
aff = ["_"] * len(mot)
#print (mot)
vies = 11
boucle = True
while vies > 0 and "_" in aff :
    print ("\n" + " ".join(aff))
    lettre = input("> ")
    if lettre in mot :
        i = 0
        while i < len(mot) :
            if mot[i] == lettre : aff[i] = lettre
            i += 1
    else : vies -= 1
if vies == 0 : print ("perdu c'était " + mot)
else : print ("gagné")
