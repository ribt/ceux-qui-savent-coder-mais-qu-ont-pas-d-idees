import feedparser
ville = "Caen"
jours = 2
data = feedparser.parse("http://api.meteorologic.net/forecarss?p=" + ville)['entries'][0]['summary']
if data == "" : print ("ville inconnue")
elif not(1 <= jours <= 7) : print ("jour entre 1 et 7 stp")
else :
    data = data.replace("<strong>", "").replace("</strong>", "").replace("\t", "").replace("<br />", "\n")
    data = data.split("\n\n\n")[:-1]
    data[0] = "\n" + data[0]
    i = 0
    while i < len(data) and i < jours :
        data[i] = data[i].split("\n")[1:-1]
        data[i][0] = "__" + data[i][0] + " :__"
        print ("\n".join(data[i]))
        i += 1
